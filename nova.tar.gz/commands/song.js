const axios = require('axios');

const config = require('../config/default.json'); // Using config for branding

module.exports = {

  name: 'song',

  alias: ['play', 'music', 'ytmp3'],

  description: 'Download YouTube audio via search or link',

  category: 'download',

  exec: async (sock, msg, args, { helpers }) => {

    const query = args.join(' ');

    if (!query) return helpers.reply(msg, `❌ *Usage:* .song <name/link>`);

    // Detect if input is a YouTube URL

    const isUrl = query.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)[a-zA-Z0-9_-]{11}/);

    try {

      // 1. Start Reaction

      await sock.sendMessage(msg.key.remoteJid, { react: { text: '🔍', key: msg.key } });

      let downloadData;

      

      if (isUrl) {

        // Use Link Downloader API

        const apiUrl = `https://api.nekolabs.web.id/downloader/youtube/v1?url=${encodeURIComponent(query)}&format=mp3`;

        const { data } = await axios.get(apiUrl);

        if (!data.success) throw new Error('API Error');

        

        downloadData = {

          title: data.result.title,

          channel: 'YouTube Video',

          cover: data.result.cover,

          url: query,

          downloadUrl: data.result.downloadUrl

        };

      } else {

        // Use Search Play API

        const apiUrl = `https://api.nekolabs.web.id/downloader/youtube/play/v1?q=${encodeURIComponent(query)}`;

        const { data } = await axios.get(apiUrl);

        if (!data.success) throw new Error('API Error');

        

        downloadData = {

          title: data.result.metadata.title,

          channel: data.result.metadata.channel,

          cover: data.result.metadata.cover,

          url: data.result.metadata.url,

          downloadUrl: data.result.downloadUrl

        };

      }

      // 2. Downloading Reaction

      await sock.sendMessage(msg.key.remoteJid, { react: { text: '📥', key: msg.key } });

      // 3. Send Audio with Metadata

      await sock.sendMessage(msg.key.remoteJid, {

        audio: { url: downloadData.downloadUrl },

        mimetype: 'audio/mpeg',

        fileName: `${downloadData.title}.mp3`,

        contextInfo: {

          externalAdReply: {

            title: downloadData.title,

            body: `Channel: ${downloadData.channel} | ${config.footer}`, // Footer integration

            thumbnailUrl: downloadData.cover,

            sourceUrl: downloadData.url,

            mediaType: 1,

            renderLargerThumbnail: true

          }

        }

      }, { quoted: msg });

      // 4. Success Reaction

      await sock.sendMessage(msg.key.remoteJid, { react: { text: '✅', key: msg.key } });

    } catch (err) {

      console.error('Song Error:', err.message);

      await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });

      helpers.reply(msg, '❌ *Error:* Could not process your request.');

    }

  }

};

