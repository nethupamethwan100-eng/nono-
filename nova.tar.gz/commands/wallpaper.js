const axios = require('axios')
const cheerio = require('cheerio')
const config = require('../config/default.json')

module.exports = {
  name: 'wallpaper',
  alias: ['wp', 'wall'],
  description: 'Search and get wallpapers',
  category: 'media',

  exec: async (sock, msg, args, { helpers, PREFIX }) => {
    await helpers.react(msg, '🖼️')

    // No query → send guide
    if (!args.length) {
      return helpers.reply(
        msg,
        `🖼️ *Wallpaper Command Guide*\n\n` +
        `Usage: \`${PREFIX}wp <keyword>\`\n` +
        `Example: \`${PREFIX}wp mountains\`\n\n` +
        `You will get up to 10 wallpaper results per search.\n` +
        `${config.footer || '> © My Cool Shadow'}`
      )
    }

    const query = args.join(' ')

    try {
      const url = `https://flix.srkh.in/search/${encodeURIComponent(query)}`
      const res = await axios.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
        timeout: 10000
      })

      const $ = cheerio.load(res.data)
      const images = []

      $('img').each((i, el) => {
        if (images.length >= 10) return

        const src = $(el).attr('src') || $(el).attr('data-src')
        if (!src) return

        // ✅ Filter to skip logos and only get real wallpapers
        if (
          src.startsWith('http') &&
          (src.endsWith('.jpg') || src.endsWith('.jpeg') || src.endsWith('.png')) &&
          !src.includes('logo') &&
          !src.includes('icon') &&
          !src.includes('favicon')
        ) {
          images.push(src)
        }
      })

      if (!images.length) {
        return helpers.reply(
          msg,
          `❌ No wallpapers found for *${query}*\nTry another keyword.`
        )
      }

      // Send wallpapers with 1s delay
      for (let i = 0; i < images.length; i++) {
        await sock.sendMessage(
          msg.key.remoteJid,
          {
            image: { url: images[i] },
            caption:
              `🖼️ *Wallpaper Result ${i + 1}/${images.length}*\n` +
              `🔎 Query: *${query}*\n\n` +
              `${config.footer || '> © My Cool Shadow'}`
          },
          { quoted: msg }
        )

        // ⏱ 1 second delay to avoid rate limits
        await new Promise(resolve => setTimeout(resolve, 500))
      }

    } catch (err) {
      console.error('Wallpaper error:', err.message)
      await helpers.reply(
        msg,
        `⚠️ Wallpaper service unavailable\nPlease try again later.`
      )
    }
  }
}