const axios = require('axios');

const config = require('../config/default.json'); // Using config for branding

module.exports = {

  name: 'instagram',

  alias: ['ig', 'igdl', 'reel'],

  description: 'Download Instagram Reels and Videos',

  category: 'download',

  exec: async (sock, msg, args, { helpers }) => {

    const url = args[0];

    

    // 1. Basic Validation

    if (!url) {

      return helpers.reply(msg, `❌ *Usage:* .ig <instagram_link>`);

    }

    try {

      // 2. Search Reaction

      await sock.sendMessage(msg.key.remoteJid, { 

        react: { text: '🔍', key: msg.key } 

      });

      const apiUrl = `https://apis.davidcyriltech.my.id/download/aiov2?url=${encodeURIComponent(url)}`;

      const { data } = await axios.get(apiUrl);

      if (!data.status || !data.result || data.result.length === 0) {

        await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });

        return helpers.reply(msg, '❌ *Error:* Failed to fetch Instagram media.');

      }

      // 3. Download Reaction

      await sock.sendMessage(msg.key.remoteJid, { 

        react: { text: '📥', key: msg.key } 

      });

      const res = data.result[0];

      const videoUrl = res.video_download;

      const title = res.title || 'Instagram Media';

      // 4. Boxed UI Styling

      const caption = `╭───[ 🎬 *IG DL* ]──╮\n` +

                      `│ ▸ *Title:* ${title.trim().substring(0, 50)}...\n` +

                      `│ ▸ *Source:* Instagram\n` +

                      `╰─────────────╯\n\n` +

                      `${config.footer}`; // Apply watermark from config

      // 5. Send Video

      await sock.sendMessage(msg.key.remoteJid, {

        video: { url: videoUrl },

        caption: caption,

        mimetype: 'video/mp4'

      }, { quoted: msg });

      // 6. Success Reaction

      await sock.sendMessage(msg.key.remoteJid, { 

        react: { text: '✅', key: msg.key } 

      });

    } catch (err) {

      console.error('IG Error:', err.message);

      await sock.sendMessage(msg.key.remoteJid, { react: { text: '❗', key: msg.key } });

    }

  }

};

