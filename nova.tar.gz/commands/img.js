const axios = require('axios')
const cheerio = require('cheerio')
const config = require('../config/default.json')

module.exports = {
    name: 'img',
    alias: ['image', 'images', 'pic'],
    desc: 'Search and download images from the web',
    category: 'search',

    async exec(sock, msg, args, { sender, isGroup, helpers, PREFIX }) {
        const FOOTER = config.footer || '© Powered by Your Bot'
        try {
            // Check if search query provided
            if (args.length === 0) {
                return await helpers.reply(msg, 
                    `🖼️ *IMAGE SEARCH*\n\n` +
                    `*Usage:*\n\`${PREFIX}img <search query>\`\n\n` +
                    `*Examples:*\n` +
                    `\`${PREFIX}img nature\`\n` +
                    `\`${PREFIX}img cars\`\n` +
                    `\`${PREFIX}img anime\`\n` +
                    `\`${PREFIX}img mountains\`\n\n` +
                    `${config.footer}`
                )
            }

            const query = args.join(' ').trim().toLowerCase()

            // Block inappropriate search terms
            const blockedWords = [
                'porn', 'sex', 'nude', 'naked', 'xxx', 'nsfw', 'adult', 'fuck',
                'pussy', 'dick', 'cock', 'boobs', 'tits', 'ass', 'penis', 'vagina',
                'horny', 'lesbian', 'gay porn', 'sexy', 'hot girl', 'bikini porn',
                'erotic', 'hentai', 'rape', 'incest', 'bdsm', 'fetish', 'orgasm',
                'masturbate', 'blowjob', 'anal', 'milf', 'teen porn', 'child', 'kid porn',
                'loli', 'shota', 'underage', 'pedophile', 'pedo'
            ]

            // Check if query contains blocked words
            const containsBlockedWord = blockedWords.some(word => {
                return query.includes(word) || query.replace(/\s+/g, '').includes(word.replace(/\s+/g, ''))
            })

            if (containsBlockedWord) {
                await helpers.react(msg, '⚠️')
                return await helpers.reply(msg,
                    `⚠️ *INAPPROPRIATE CONTENT BLOCKED*\n\n` +
                    `❌ Your search query contains inappropriate or explicit content.\n\n` +
                    `🚫 This bot does not allow searches for:\n` +
                    `• Adult content\n` +
                    `• Explicit material\n` +
                    `• Inappropriate images\n\n` +
                    `✅ Please use respectful and appropriate search terms.\n\n` +
                    `${config.footer}`
                )
            }

            // Send searching reaction
            await helpers.react(msg, '🔍')
            await helpers.reply(msg, `🔍 Searching for images: *${query}*\n\n_Please wait..._`)

            // Search images using Bing Image Search
            const searchUrl = `https://www.bing.com/images/search?q=${encodeURIComponent(query)}&first=1`

            const response = await axios({
                method: 'GET',
                url: searchUrl,
                timeout: 15000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                }
            })

            const $ = cheerio.load(response.data)
            const imageUrls = []

            // Extract image URLs from Bing results
            $('a.iusc').each((index, element) => {
                if (imageUrls.length >= 5) return false

                try {
                    const m = $(element).attr('m')
                    if (m) {
                        const data = JSON.parse(m)
                        if (data.murl) {
                            imageUrls.push(data.murl)
                        }
                    }
                } catch (e) {
                    // Skip invalid entries
                }
            })

            if (imageUrls.length === 0) {
                await helpers.react(msg, '❌')
                return await helpers.reply(msg, `❌ *No images found*\n\nTry searching with different keywords.\n\n${config.footer}`)
            }

            await helpers.react(msg, '⬇️')

            // Send images
            for (let i = 0; i < imageUrls.length; i++) {
                try {
                    await helpers.sendImage(
                        sender, 
                        imageUrls[i], 
                        `📸 *Image ${i + 1}/${imageUrls.length}*\n🔍 Query: ${query}\n\n${config.footer}`
                    )

                    // Small delay between images
                    if (i < imageUrls.length - 1) {
                        await new Promise(resolve => setTimeout(resolve, 800))
                    }
                } catch (imgError) {
                    console.error(`Failed to send image ${i + 1}:`, imgError.message)
                    continue
                }
            }

            await helpers.react(msg, '✅')

        } catch (error) {
            console.error('Image search error:', error)
            await helpers.react(msg, '❌')
            await helpers.reply(msg, 
                `❌ *Search Failed*\n\n` +
                `Error: ${error.message}\n\n` +
                `Please try again with different keywords.\n\n` +
                `${config.footer}`
            )
        }
    }
}