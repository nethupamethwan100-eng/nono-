const { downloadMediaMessage } = require('@whiskeysockets/baileys')
const sharp = require('sharp')

module.exports = {
  name: 'toimg',
  alias: ['toimage', 'stickertoimg', 'sti'],
  description: 'Convert sticker to image',
  category: 'converter',
  exec: async (sock, msg, args, { helpers }) => {
    try {
      let quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage

      // Check if replying to a sticker
      if (!quotedMsg || !quotedMsg.stickerMessage) {
        return await helpers.reply(msg, '❌ Please reply to a sticker!')
      }

      // Download sticker
      const stickerBuffer = await downloadMediaMessage(
        { message: quotedMsg },
        'buffer',
        {}
      )

      // Convert webp to png using sharp
      const imageBuffer = await sharp(stickerBuffer)
        .png()
        .toBuffer()

      // Send as image
      await sock.sendMessage(msg.key.remoteJid, {
        image: imageBuffer,
        caption: '✅ Converted to image'
      })

    } catch (error) {
      console.error('ToImg error:', error)
      await helpers.reply(msg, '❌ Failed to convert sticker to image!')
    }
  }
}