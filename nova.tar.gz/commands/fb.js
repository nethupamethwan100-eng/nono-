const axios = require('axios');

const config = require('../config/default.json'); // Using config for branding

module.exports = {

  name: 'facebook',

  alias: ['fb', 'fbdl'],

  description: 'Download Facebook videos directly',

  category: 'download',

  exec: async (sock, msg, args, { helpers }) => {

    const url = args[0];

    

    // 1. Basic Validation

    if (!url) {

      return helpers.reply(msg, `❌ *Usage:* .fb <link>`);

    }

    try {

      // 2. Initial Reaction for "Searching"

      await sock.sendMessage(msg.key.remoteJid, { 

        react: { text: '🔍', key: msg.key } 

      });

      const apiUrl = `https://apis.davidcyriltech.my.id/facebook?url=${encodeURIComponent(url)}`;

      const { data } = await axios.get(apiUrl);

      if (!data.success || !data.result) {

        await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });

        return helpers.reply(msg, '❌ *Error:* Failed to fetch video.');

      }

      // 3. Update Reaction for "Downloading"

      await sock.sendMessage(msg.key.remoteJid, { 

        react: { text: '📥', key: msg.key } 

      });

      const res = data.result;

      // Auto-select HD if available, otherwise SD

      const videoUrl = res.downloads.hd.url || res.downloads.sd.url;

      // 4. UI Styling based on Help command hierarchy

      const caption = `╭───〔 🎬 *FB Dl* 〕──╮\n` +

                      `│ ▸ *Title:* Facebook Video\n` +

                      `│ ▸ *Quality:* ${res.downloads.hd.url ? 'High Quality (HD)' : 'Standard (SD)'}\n` +

                      `╰─────────────╯\n\n` +

                      `${config.footer}`; // Apply watermark from config

      // 5. Send Video

      await sock.sendMessage(msg.key.remoteJid, {

        video: { url: videoUrl },

        caption: caption,

        mimetype: 'video/mp4'

      }, { quoted: msg });

      // 6. Success Reaction

      await sock.sendMessage(msg.key.remoteJid, { 

        react: { text: '✅', key: msg.key } 

      });

    } catch (err) {

      console.error('FB Error:', err.message);

      await sock.sendMessage(msg.key.remoteJid, { react: { text: '❗', key: msg.key } });

    }

  }

};

