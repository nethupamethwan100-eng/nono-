const { execSync } = require("child_process");

function run(cmd) {

  execSync(cmd, { stdio: "inherit" });

}

console.log("⚡ FORCE START MODE");

// Force install PM2

console.log("📦 Installing PM2 (force)...");

run("npm install -g pm2");

// Install dependencies

console.log("📦 Installing node modules...");

run("npm install --force");

// Kill old process if exists

console.log("🧹 Cleaning old PM2 process...");

run("pm2 delete shadow-n-pro || true");

// Start app

console.log("🔥 Starting index.js with PM2...");

run("pm2 start index.js --name shadow-n-pro");

// Save process list

run("pm2 save");

// Enable startup (ignore errors)

run("pm2 startup || true");

// Show status

run("pm2 status");

console.log("✅ FORCE START COMPLETE");