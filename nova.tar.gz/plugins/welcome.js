module.exports = {
  event: 'group-participants.update',
  exec: async (sock, update) => {
    const { id, participants, action } = update

    try {
      // Welcome new members
      if (action === 'add') {
        const welcomeText = `👋 Welcome to the group!\n\n`
          + participants.map(p => `@${p.split('@')[0]}`).join(', ')
          + `\n\nEnjoy your stay! 🎉`

        await sock.sendMessage(id, {
          text: welcomeText,
          mentions: participants
        })
      }

      // Goodbye message
      if (action === 'remove') {
        const goodbyeText = `👋 Goodbye!\n\n`
          + participants.map(p => `@${p.split('@')[0]}`).join(', ')
          + ` left the group.`

        await sock.sendMessage(id, {
          text: goodbyeText,
          mentions: participants
        })
      }

      // Promote notification
      if (action === 'promote') {
        const promoteText = `🎉 Congratulations!\n\n`
          + participants.map(p => `@${p.split('@')[0]}`).join(', ')
          + ` is now an admin!`

        await sock.sendMessage(id, {
          text: promoteText,
          mentions: participants
        })
      }

      // Demote notification
      if (action === 'demote') {
        const demoteText = participants.map(p => `@${p.split('@')[0]}`).join(', ')
          + ` is no longer an admin.`

        await sock.sendMessage(id, {
          text: demoteText,
          mentions: participants
        })
      }

    } catch (err) {
      console.error('Welcome plugin error:', err)
    }
  }
}