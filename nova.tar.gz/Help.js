const fs = require('fs')

const path = require('path')

const config = require('../config/default.json')

// Store help menu for each user (expires after 5 minutes)

const userHelpMenus = new Map()

module.exports = {

  name: 'help',

  alias: ['h', 'menu', 'commands'],

  

  // Handler for number replies (called from main bot)

  handleReply: async (sock, msg, helpers) => {

    try {

      const messageText = 

        msg.message.conversation ||

        msg.message.extendedTextMessage?.text ||

        ''

      const sender = msg.key.remoteJid

      

      // Check if user has an active help menu

      const userData = userHelpMenus.get(sender)

      if (!userData) return false

      // Check if the message is a number

      const selectedNum = parseInt(messageText.trim())

      if (isNaN(selectedNum) || selectedNum < 1) return false

      const categories = userData.categories

      const categoryNum = selectedNum - 1

      if (categoryNum >= 0 && categoryNum < categories.length) {

        const selectedCategory = categories[categoryNum]

        const cmds = userData.commands[selectedCategory]

        // Category emoji mapper

        const categoryEmojis = {

          'general': '⚙️',

          'ai': '🤖',

          'utility': '🛠️',

          'search': '🔍',

          'converter': '🔄',

          'media': '🎬',

          'download': '📥',

          'fun': '🎮',

          'admin': '👑',

          'info': '📊'

        }

        const emoji = categoryEmojis[selectedCategory.toLowerCase()] || '✨'

        let categoryText = `╭─〔 ${emoji} *${selectedCategory.toUpperCase()}* 〕─╮\n`

        for (const cmd of cmds) {

          const aliases = cmd.alias ? ` (${cmd.alias.join(', ')})` : ''

          const desc = cmd.description || 'No description'

          categoryText += `│ ▸ *.${cmd.name}${aliases}*\n`

          categoryText += `│   ↳ \`\`\`${desc}\`\`\`\n│\n`

        }

        categoryText += `╰─────────────╯\n\n${config.footer}`

        await helpers.sendImage(

          sender,

          'https://i.postimg.cc/5NLPczBD/Leonardo-Anime-XL-Animestyle-illustration-Narutoinspired-chara-2.jpg',

          categoryText

        )

        return true // Handled

      }

      return false

    } catch (err) {

      return false

    }

  },

  exec: async (sock, msg, args, { helpers, PREFIX }) => {

    try {

      // Get all command files

      const commandPath = path.join(__dirname)

      const commandFiles = fs.readdirSync(commandPath).filter(f => f.endsWith('.js'))

      // Load and categorize commands

      const commands = {}

      for (const file of commandFiles) {

        try {

          const cmd = require(path.join(commandPath, file))

          const category = cmd.category || 'general'

          if (!commands[category]) commands[category] = []

          commands[category].push(cmd)

        } catch (err) {

          console.error(`Error loading ${file}:`, err)

        }

      }

      // Convert bot name to fancy text style

      const fancyBotName = config.botName.toUpperCase().split('').join(' ')

      // Number emojis

      const numberEmojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟']

      // Main menu

      let helpText = `╭──[ *✦ ${fancyBotName}* ]─╮

│ 🖇️ ᴘʀᴇꜰɪx : ${config.prefix}

│ 🧩 ᴄᴍᴅꜱ : ${commandFiles.length}

│ 📂 ᴄᴀᴛꜱ  : ${Object.keys(commands).length}

│ 🛡️ ᴏɴʟɪɴᴇ

╰─────────────╯

`

      const categories = Object.keys(commands)

      categories.forEach((category, index) => {

        const emoji = numberEmojis[index] || '▸'

        helpText += `    ${emoji} *${category.charAt(0).toUpperCase() + category.slice(1)}*\n`

      })

      helpText += `\n_Send number to view category_\n\n${config.footer}`

      // Send main menu

      await helpers.sendImage(

        msg.key.remoteJid,

        'https://i.postimg.cc/5NLPczBD/Leonardo-Anime-XL-Animestyle-illustration-Narutoinspired-chara-2.jpg',

        helpText

      )

      // Store user's help menu data (expires after 5 minutes)

      userHelpMenus.set(msg.key.remoteJid, {

        categories,

        commands,

        timestamp: Date.now()

      })

      // Auto-delete after 5 minutes

      setTimeout(() => {

        userHelpMenus.delete(msg.key.remoteJid)

      }, 300000)

    } catch (err) {

      await helpers.reply(msg, '❌ Error loading help menu')

    }

  }

}