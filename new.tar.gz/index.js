const { default: makeWASocket, DisconnectReason, useMultiFileAuthState, Browsers, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys')

const pino = require('pino')

const fs = require('fs')

const path = require('path')

require('dotenv').config()

// Load config

const config = require('./config/default.json')

const PREFIX = process.env.PREFIX || config.prefix || '!'

const OWNER = process.env.OWNER_NUMBER || config.owner

// Rate limiting configuration

const RATE_LIMIT = {

    maxPerSecond: 3,

    maxPerMinute: 20,

    cooldownMs: 1000,

    maxQueueSize: 50

}

// Storage for commands and plugins

const commands = new Map()

const plugins = []

// Memory management

let sock = null

let reconnectTimeout = null

let messageQueue = new Set()

// Message processing queue with rate limiting

class MessageProcessor {

    constructor() {

        this.queue = []

        this.processing = false

        this.messageCount = { second: 0, minute: 0 }

        this.lastMessageTime = 0

        

        setInterval(() => { this.messageCount.second = 0 }, 1000)

        setInterval(() => { this.messageCount.minute = 0 }, 60000)

    }

    async add(task) {

        if (this.queue.length >= RATE_LIMIT.maxQueueSize) {

            return

        }

        this.queue.push(task)

        

        if (!this.processing) {

            this.process()

        }

    }

    async process() {

        this.processing = true

        while (this.queue.length > 0) {

            if (this.messageCount.second >= RATE_LIMIT.maxPerSecond) {

                await this.sleep(1000)

                continue

            }

            if (this.messageCount.minute >= RATE_LIMIT.maxPerMinute) {

                await this.sleep(60000)

                continue

            }

            const now = Date.now()

            const timeSinceLastMessage = now - this.lastMessageTime

            if (timeSinceLastMessage < RATE_LIMIT.cooldownMs) {

                await this.sleep(RATE_LIMIT.cooldownMs - timeSinceLastMessage)

            }

            const task = this.queue.shift()

            

            try {

                await task()

                this.messageCount.second++

                this.messageCount.minute++

                this.lastMessageTime = Date.now()

            } catch (err) {

            }

            await this.sleep(350)

        }

        this.processing = false

    }

    sleep(ms) {

        return new Promise(resolve => setTimeout(resolve, ms))

    }

    getQueueSize() {

        return this.queue.length

    }

    clear() {

        this.queue = []

        this.processing = false

    }

}

const messageProcessor = new MessageProcessor()

// Create database folder

const databasePath = path.join(__dirname, 'database')

if (!fs.existsSync(databasePath)) {

    fs.mkdirSync(databasePath, { recursive: true })

}

// Track if connection message was sent

const connectionStatusFile = path.join(databasePath, 'connection_sent.json')

let connectionMessageSent = fs.existsSync(connectionStatusFile)

// Cleanup function

function cleanup() {

    if (reconnectTimeout) {

        clearTimeout(reconnectTimeout)

        reconnectTimeout = null

    }

    

    if (messageQueue.size > 1000) {

        const arr = Array.from(messageQueue)

        messageQueue.clear()

        arr.slice(-500).forEach(id => messageQueue.add(id))

    }

}

// Load all commands

function loadCommands() {

    commands.clear()

    const commandPath = path.join(__dirname, 'commands')

    

    if (!fs.existsSync(commandPath)) {

        return

    }

    

    const commandFiles = fs.readdirSync(commandPath).filter(f => f.endsWith('.js'))

    for (const file of commandFiles) {

        try {

            const filePath = path.join(commandPath, file)

            delete require.cache[require.resolve(filePath)]

            

            const command = require(filePath)

            commands.set(command.name, command)

            if (command.alias && Array.isArray(command.alias)) {

                command.alias.forEach(a => commands.set(a, command))

            }

        } catch (err) {

        }

    }

}

// Load all plugins

function loadPlugins() {

    plugins.length = 0

    const pluginPath = path.join(__dirname, 'plugins')

    

    if (!fs.existsSync(pluginPath)) return

    const pluginFiles = fs.readdirSync(pluginPath).filter(f => f.endsWith('.js'))

    for (const file of pluginFiles) {

        try {

            const filePath = path.join(pluginPath, file)

            delete require.cache[require.resolve(filePath)]

            

            const plugin = require(filePath)

            plugins.push(plugin)

        } catch (err) {

        }

    }

}

// Helper functions generator with rate-limited sending

function createHelpers(sock) {

    const rateLimitedSend = async (sendFunction) => {

        return new Promise((resolve, reject) => {

            messageProcessor.add(async () => {

                try {

                    const result = await sendFunction()

                    resolve(result)

                } catch (err) {

                    reject(err)

                }

            })

        })

    }

    return {

        sendText: async (jid, text, options = {}) => {

            return rateLimitedSend(() => 

                sock.sendMessage(jid, { text, ...options })

            )

        },

        reply: async (msg, text) => {

            return rateLimitedSend(() => 

                sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg })

            )

        },

        sendImage: async (jid, media, caption = '', options = {}) => {

            return rateLimitedSend(() => 

                sock.sendMessage(jid, { image: { url: media }, caption, ...options })

            )

        },

        sendVideo: async (jid, media, caption = '', options = {}) => {

            return rateLimitedSend(() => 

                sock.sendMessage(jid, { video: { url: media }, caption, ...options })

            )

        },

        sendAudio: async (jid, media, options = {}) => {

            return rateLimitedSend(() => 

                sock.sendMessage(jid, { audio: { url: media }, mimetype: 'audio/mp4', ...options })

            )

        },

        sendSticker: async (jid, media, options = {}) => {

            return rateLimitedSend(() => 

                sock.sendMessage(jid, { sticker: { url: media }, ...options })

            )

        },

        sendDocument: async (jid, media, filename, mimetype, caption = '') => {

            return rateLimitedSend(() => 

                sock.sendMessage(jid, { 

                    document: { url: media }, 

                    fileName: filename,

                    mimetype,

                    caption 

                })

            )

        },

        editMsg: async (msg, newText) => {

            return sock.sendMessage(msg.key.remoteJid, {

                text: newText,

                edit: msg.key

            })

        },

        deleteMsg: async (msg) => {

            return sock.sendMessage(msg.key.remoteJid, { 

                delete: msg.key 

            })

        },

        react: async (msg, emoji) => {

            return sock.sendMessage(msg.key.remoteJid, {

                react: { text: emoji, key: msg.key }

            })

        },

        downloadMedia: async (msg) => {

            try {

                const buffer = await sock.downloadMediaMessage(msg)

                return buffer

            } catch (err) {

                return null

            }

        },

        sendTyping: async (jid, duration = 3000) => {

            await sock.sendPresenceUpdate('composing', jid)

            setTimeout(() => sock.sendPresenceUpdate('paused', jid), duration)

        },

        sendRecording: async (jid, duration = 3000) => {

            await sock.sendPresenceUpdate('recording', jid)

            setTimeout(() => sock.sendPresenceUpdate('paused', jid), duration)

        },

        groupMetadata: async (jid) => {

            return await sock.groupMetadata(jid)

        },

        groupAdd: async (jid, participants) => {

            return await sock.groupParticipantsUpdate(jid, participants, 'add')

        },

        groupKick: async (jid, participants) => {

            return await sock.groupParticipantsUpdate(jid, participants, 'remove')

        },

        groupPromote: async (jid, participants) => {

            return await sock.groupParticipantsUpdate(jid, participants, 'promote')

        },

        groupDemote: async (jid, participants) => {

            return await sock.groupParticipantsUpdate(jid, participants, 'demote')

        },

        groupUpdateSubject: async (jid, subject) => {

            return await sock.groupUpdateSubject(jid, subject)

        },

        groupUpdateDesc: async (jid, description) => {

            return await sock.groupUpdateDescription(jid, description)

        },

        isAdmin: async (jid, participant) => {

            try {

                const metadata = await sock.groupMetadata(jid)

                const admins = metadata.participants.filter(p => p.admin).map(p => p.id)

                return admins.includes(participant)

            } catch {

                return false

            }

        },

        getQueueStatus: () => ({

            size: messageProcessor.getQueueSize(),

            processing: messageProcessor.processing,

            stats: messageProcessor.messageCount

        })

    }

}

// Main connection function

async function connectToWhatsApp() {

    cleanup()

    

    const sessionPath = './session'

    if (!fs.existsSync(sessionPath) || fs.readdirSync(sessionPath).length === 0) {

        process.exit(1)

    }

    const { state, saveCreds } = await useMultiFileAuthState('session')

    sock = makeWASocket({

        auth: {

            creds: state.creds,

            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))

        },

        browser: Browsers.ubuntu('WhatsApp Bot'),

        logger: pino({ level: 'silent' }),

        printQRInTerminal: false,

        defaultQueryTimeoutMs: undefined,

        connectTimeoutMs: 60000,

        keepAliveIntervalMs: 30000,

        getMessage: async (key) => {

            return { conversation: '' }

        },

        shouldIgnoreJid: (jid) => {

            return jid === 'status@broadcast'

        },

        markOnlineOnConnect: false,

        syncFullHistory: false,

        fireInitQueries: true,

        generateHighQualityLinkPreview: false

    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('connection.update', async (update) => {

        const { connection, lastDisconnect } = update

        if (connection === 'close') {

            const statusCode = lastDisconnect?.error?.output?.statusCode

            if (statusCode === DisconnectReason.badSession) {

                process.exit(1)

            } else if (statusCode === DisconnectReason.connectionReplaced) {

                process.exit(0)

            } else if (statusCode === DisconnectReason.loggedOut) {

                process.exit(1)

            } else if (statusCode === 405) {

                process.exit(1)

            } else {

                cleanup()

                messageProcessor.clear()

                reconnectTimeout = setTimeout(() => connectToWhatsApp(), 5000)

            }

        } else if (connection === 'open') {

            if (!connectionMessageSent && OWNER) {

                try {

                    const ownerJid = OWNER + '@s.whatsapp.net'

                    const connectionTime = new Date().toLocaleString('en-US', {

                        dateStyle: 'full',

                        timeStyle: 'short',

                        timeZone: 'Asia/Colombo'

                    })

                    const imagePath = path.join(__dirname, 'media', 'connected.jpg')

                    const imageExists = fs.existsSync(imagePath)

                    const messageText = `✅ *Bot Connected Successfully!*\n\n` +

                                      `🤖 Bot is now online and ready!\n` +

                                      `🕐 Connected: ${connectionTime}\n` +

                                      `⚡ Prefix: ${PREFIX}\n` +

                                      `📊 Status: Active ✅\n` +

                                      `📝 Commands: ${commands.size} loaded\n` +

                                      `🔌 Plugins: ${plugins.length} loaded\n` +

                                      `🚦 Rate Limit: ${RATE_LIMIT.maxPerSecond}/sec\n\n` +

                                      `_Type ${PREFIX}menu to see commands_`

                    if (imageExists) {

                        await sock.sendMessage(ownerJid, { 

                            image: { url: imagePath },

                            caption: messageText

                        })

                    } else {

                        await sock.sendMessage(ownerJid, { text: messageText })

                    }

                    connectionMessageSent = true

                    fs.writeFileSync(connectionStatusFile, JSON.stringify({

                        sent: true,

                        timestamp: new Date().toISOString()

                    }, null, 2))

                } catch (err) {

                }

            }

        }

    })

    // Group participant updates

    sock.ev.on('group-participants.update', async (update) => {

        for (const plugin of plugins) {

            if (plugin.event === 'group-participants.update') {

                try {

                    await plugin.exec(sock, update)

                } catch (err) {

                }

            }

        }

    })

    const helpers = createHelpers(sock)

    // Message handler

    sock.ev.on('messages.upsert', async ({ messages, type }) => {

        try {

            if (type !== 'notify') return

            const msg = messages[0]

            if (!msg || !msg.message) return

            const msgId = `${msg.key.remoteJid}_${msg.key.id}`

            

            if (messageQueue.has(msgId)) return

            messageQueue.add(msgId)

            if (msg.key.remoteJid === 'status@broadcast') return

            const messageText = 

                msg.message.conversation ||

                msg.message.extendedTextMessage?.text ||

                msg.message.imageMessage?.caption ||

                msg.message.videoMessage?.caption ||

                ''

            // Check for reply handlers (without prefix)

            if (!messageText.startsWith(PREFIX)) {

                // Loop through all commands to check if any has a reply handler

                for (const [cmdName, command] of commands.entries()) {

                    if (command.handleReply && typeof command.handleReply === 'function') {

                        const handled = await command.handleReply(sock, msg, helpers)

                        if (handled) return

                    }

                }

                return

            }

            const args = messageText.slice(PREFIX.length).trim().split(/ +/)

            const commandName = args.shift()?.toLowerCase()

            if (!commandName) return

            const command = commands.get(commandName)

            if (!command) return

            const sender = msg.key.remoteJid

            const isGroup = sender.endsWith('@g.us')

            const pushname = msg.pushName || 'User'

            const senderNumber = sender.replace('@s.whatsapp.net', '').split('@')[0]

            const commandPromise = command.exec(sock, msg, args, { 

                sender, 

                isGroup, 

                pushname,

                PREFIX,

                OWNER,

                isOwner: senderNumber === OWNER || msg.key.fromMe,

                helpers

            })

            await Promise.race([

                commandPromise,

                new Promise((_, reject) => 

                    setTimeout(() => reject(new Error('Command timeout (30s)')), 30000)

                )

            ])

        } catch (err) {

            try {

                const msg = messages[0]

                if (msg && msg.key) {

                    await helpers.reply(msg, `❌ Error: ${err.message}`)

                }

            } catch {}

        }

    })

    return sock

}

// Initialize bot

async function init() {

    loadCommands()

    loadPlugins()

    await connectToWhatsApp()

}

// Graceful shutdown

async function shutdown() {

    cleanup()

    messageProcessor.clear()

    

    if (sock) {

        try {

            await sock.logout()

        } catch {}

    }

    

    process.exit(0)

}

// Start the bot

init().catch(err => {

    process.exit(1)

})

process.on('SIGINT', shutdown)

process.on('SIGTERM', shutdown)

process.on('uncaughtException', err => {

})

process.on('unhandledRejection', err => {

})

if (process.env.MONITOR_MEMORY === 'true') {

    let lastWarning = 0

    setInterval(() => {

        const usage = process.memoryUsage()

        const heapMB = Math.round(usage.heapUsed / 1024 / 1024)

        const queueSize = messageProcessor.getQueueSize()

        

        if (heapMB > 500 || queueSize > 10) {

            const now = Date.now()

            if (now - lastWarning > 300000) {

                lastWarning = now

            }

        }

    }, 30000)

}