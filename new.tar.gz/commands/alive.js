const config = require('../config/default.json')

module.exports = {

  name: 'alive',

  alias: ['bot', 'status', 'info'],

  description: 'Check if bot is alive and running',

  category: 'general',

  exec: async (sock, msg, args, { helpers, PREFIX }) => {

    // React with heart

    await helpers.react(msg, '❤️')

    try {

      // Get bot uptime

      const uptime = process.uptime()

      const days = Math.floor(uptime / 86400)

      const hours = Math.floor((uptime % 86400) / 3600)

      const minutes = Math.floor((uptime % 3600) / 60)

      const seconds = Math.floor(uptime % 60)

      let uptimeStr = ''

      if (days > 0) uptimeStr += `${days}d `

      if (hours > 0) uptimeStr += `${hours}h `

      if (minutes > 0) uptimeStr += `${minutes}m `

      uptimeStr += `${seconds}s`

      // Get current time

      const now = new Date().toLocaleString('en-US', {

        timeZone: config.timezone || 'Asia/Kolkata',

        dateStyle: 'medium',

        timeStyle: 'short'

      })

      // Get memory usage

      const memUsage = process.memoryUsage()

      const memUsed = (memUsage.heapUsed / 1024 / 1024).toFixed(2)

      const memTotal = (memUsage.heapTotal / 1024 / 1024).toFixed(2)

      // Build caption

      const caption = `✅ *${config.botName || 'WhatsApp Bot'} is Alive!*\n\n` +

                     `🤖 *Bot Information:*\n` +

                     `├ 📱 Status: Online & Active\n` +

                     `├ ⏱️ Uptime: ${uptimeStr}\n` +

                     `├ 🕐 Time: ${now}\n` +

                     `├ 💾 Memory: ${memUsed}MB / ${memTotal}MB\n` +

                     `├ ⚡ Prefix: ${PREFIX}\n` +

                     `└ 🌍 Timezone: ${config.timezone || 'Asia/Kolkata'}\n\n` +

                     `${config.footer || '> © My Cool Shadow'}`

      // FASTEST METHOD: Sending via remote URL

      // This streams the media directly without loading it into your server's RAM first.

      await sock.sendMessage(msg.key.remoteJid, {

        image: { url: 'https://i.postimg.cc/bJFrqcjR/IMG-20260104-WA0137.jpg' },

        caption: caption

      }, { quoted: msg })

    } catch (error) {

      console.error('Alive command error:', error)

      await helpers.reply(msg, 

        `✅ *${config.botName || 'WhatsApp Bot'} is Alive!*\n\n` +

        `🤖 Bot is running and ready to serve!\n` +

        `⚡ Prefix: ${PREFIX}\n\n` +

        `${config.footer || '> © My Cool Shadow'}`

      )

    }

  }

}

