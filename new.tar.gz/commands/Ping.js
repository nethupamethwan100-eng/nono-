module.exports = {

  name: 'ping',

  alias: ['p', 'speed', 'latency'],

  description: 'Check bot response time and speed',

  category: 'general',

  exec: async (sock, msg, args, { helpers }) => {

    // React with ping pong emoji

    await helpers.react(msg, '🏓')

    const start = Date.now()

    // Send initial message

    const sent = await helpers.reply(msg, '🏓 Pinging...')

    // Calculate latency

    const latency = Date.now() - start

    // Determine speed status

    let speedStatus = ''

    let speedEmoji = ''

    if (latency < 100) {

      speedStatus = 'Excellent'

      speedEmoji = '🟢'

    } else if (latency < 200) {

      speedStatus = 'Good'

      speedEmoji = '🟡'

    } else if (latency < 400) {

      speedStatus = 'Fair'

      speedEmoji = '🟠'

    } else {

      speedStatus = 'Slow'

      speedEmoji = '🔴'

    }

    // Get server uptime

    const uptime = process.uptime()

    const hours = Math.floor(uptime / 3600)

    const minutes = Math.floor((uptime % 3600) / 60)

    const seconds = Math.floor(uptime % 60)

    const uptimeStr = `${hours}h ${minutes}m ${seconds}s`

    // Create response message

    const response = `🏓 *Pong!*\n\n` +

                    `${speedEmoji} *Speed:* ${speedStatus}\n` +

                    `⚡ *Latency:* ${latency}ms\n` +

                    `⏱️ *Response Time:* ${latency}ms\n` +

                    `🕐 *Uptime:* ${uptimeStr}\n` +

                    `📊 *Status:* Online ✅`

    // Add a small delay to ensure message is sent

    setTimeout(async () => {

      try {

        // Try to edit the message

        await helpers.editMsg(sent, response)

      } catch (err) {

        // If edit fails, send a new message

        await helpers.reply(msg, response)

      }

    }, 100)

  }

}