const { Sticker, StickerTypes } = require('wa-sticker-formatter')
const { downloadMediaMessage } = require('@whiskeysockets/baileys')

module.exports = {
  name: 'sticker',
  alias: ['s', 'stiker', 'stick'],
  description: 'Convert image/video to sticker',
  category: 'converter',
  exec: async (sock, msg, args, { helpers }) => {
    try {
      let media
      let quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage

      // Check if replying to a media message
      if (quotedMsg) {
        const messageType = Object.keys(quotedMsg)[0]

        if (messageType === 'imageMessage' || messageType === 'videoMessage') {
          // Download quoted media
          media = await downloadMediaMessage(
            { message: quotedMsg },
            'buffer',
            {}
          )
        } else {
          return await helpers.reply(msg, '❌ Please reply to an image or video!')
        }
      } 
      // Check if message itself contains media
      else if (msg.message?.imageMessage || msg.message?.videoMessage) {
        media = await downloadMediaMessage(msg, 'buffer', {})
      } else {
        return await helpers.reply(msg, '⚠️ Please send or reply to an image/video with .sticker')
      }

      // Create sticker
      const sticker = new Sticker(media, {
        pack: 'WA Bot',
        author: 'Sticker Maker',
        type: StickerTypes.FULL,
        quality: 50
      })

      // Get sticker buffer
      const stickerBuffer = await sticker.toBuffer()

      // Send sticker
      await sock.sendMessage(msg.key.remoteJid, {
        sticker: stickerBuffer
      })

    } catch (error) {
      console.error('Sticker error:', error)
      await helpers.reply(msg, '❌ Failed to create sticker. Make sure the image/video is valid!')
    }
  }
}