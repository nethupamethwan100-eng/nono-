const axios = require('axios');

const config = require('../config/default.json');

// Session storage

const movieSessions = new Map();

const WA_LIMIT = 2048 * 1024 * 1024; // 2.0 GB Limit

module.exports = {

  name: 'movie',

  alias: ['cine', 'searchmovie'],

  category: 'search',

  description: 'Download movies using Low-RAM direct document method',

  handleReply: async (sock, msg, helpers) => {

    const sender = msg.key.remoteJid;

    const session = movieSessions.get(sender);

    if (!session) return false;

    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

    const choice = text.trim().toLowerCase();

    if (choice === 'exit') {

      movieSessions.delete(sender);

      await sock.sendMessage(sender, { react: { text: '✅', key: msg.key } });

      return true;

    }

    // --- STEP 2: DIRECT DOCUMENT UPLOAD ---

    if (session.step === 'download') {

      const qIndex = parseInt(choice) - 1;

      if (qIndex >= 0 && qIndex < session.options.length) {

        const selected = session.options[qIndex];

        // Size Validation

        if (parseInt(selected.size) > WA_LIMIT) {

          return await helpers.reply(msg, `⚠️ *File Too Heavy!* \n\nThis file is ${(selected.size / (1024**3)).toFixed(2)}GB. WhatsApp documents are capped at 2.0GB.`);

        }

        await sock.sendMessage(sender, { react: { text: '⏳', key: msg.key } });

        try {

          // LOW RAM METHOD: Sending URL directly as a document

          await sock.sendMessage(sender, {

            document: { url: selected.downloadUrl },

            mimetype: 'video/mp4',

            fileName: `${session.title}_${selected.quality}p.mp4`,

            caption: `🎬 *${session.title}*\n\n📐 *Quality:* ${selected.quality}p\n⚖️ *Size:* ${(selected.size / (1024 * 1024)).toFixed(2)} MB\n\n${config.footer}`

          }, { quoted: msg });

          await sock.sendMessage(sender, { react: { text: '✅', key: msg.key } });

        } catch (e) {

          await helpers.reply(msg, `❌ *Upload Failed:* Link expired or server timeout.`);

        }

        return true;

      }

    }

    // --- STEP 1: FETCH INFO & QUALITIES ---

    const index = parseInt(choice) - 1;

    if (index >= 0 && index < session.results?.length) {

      const item = session.results[index];

      try {

        await sock.sendMessage(sender, { react: { text: '🔍', key: msg.key } });

        // Fetch Movie Details

        const info = await axios.get(`https://apis.davidcyriltech.my.id/cineverse/info?info=${item.subjectId}`);

        const movie = info.data.data.data.subject;

        if (movie.subjectType === 1) {

          // Fetch Download Links Only After User Selection (Saves API calls)

          const source = await axios.get(`https://apis.davidcyriltech.my.id/cineverse/sources?info=${item.subjectId}`);

          const dlLinks = source.data.data.data.processedSources || [];

          let uiText = `╭──[ *MOVIE INFO* ]──╮\n│\n`;

          uiText += `│ 🎬 *${movie.title.toUpperCase()}*\n`;

          uiText += `│ 📅 *Year:* ${movie.releaseDate}\n`;

          uiText += `│ 🌟 *IMDB:* ${movie.imdbRatingValue}\n`;

          uiText += `│\n╰──────────────────╯\n\n`;

          uiText += `📥 *SELECT QUALITY TO DOWNLOAD:*\n`;

          dlLinks.forEach((dl, i) => {

            const size = dl.size > 1024**3 ? `${(dl.size/(1024**3)).toFixed(2)}GB` : `${(dl.size/(1024**2)).toFixed(0)}MB`;

            uiText += `${i + 1}. 🎥 *${dl.quality}p* _(${size})_\n`;

          });

          uiText += `\n_Reply with number to send document._`;

          session.step = 'download';

          session.title = movie.title;

          session.options = dlLinks;

          await helpers.sendImage(sender, movie.cover.url, uiText);

        } else {

          await helpers.reply(msg, `📺 TV Series selection detected. Logic for seasons is being updated.`);

        }

        await sock.sendMessage(sender, { react: { text: '⭐', key: msg.key } });

      } catch (err) {

        await helpers.reply(msg, `❌ API Error: ${err.message}`);

      }

      return true;

    }

    return false;

  },

  exec: async (sock, msg, args, { helpers }) => {

    const sender = msg.key.remoteJid;

    const query = args.join(' ');

    if (!query) return await helpers.reply(msg, '❌ Please provide a movie name!');

    try {

      await sock.sendMessage(sender, { react: { text: '🔍', key: msg.key } });

      const res = await axios.get(`https://apis.davidcyriltech.my.id/cineverse?q=${encodeURIComponent(query)}`);

      const items = res.data.data.data.items.slice(0, 25);

      if (items.length === 0) return await helpers.reply(msg, '❌ No movies found.');

      let list = `🎬 *CINEVERSE SEARCH*\n\n`;

      items.forEach((item, i) => {

        const emoji = item.subjectType === 2 ? '📺' : '🎥';

        list += `${i + 1}. ${emoji} *${item.title}*\n`;

      });

      list += `\n_Reply with number for details_`;

      await helpers.reply(msg, list);

      // Save session with 10-minute expiry

      movieSessions.set(sender, { results: items, step: 'search', timestamp: Date.now() });

      setTimeout(() => movieSessions.delete(sender), 600000);

    } catch (e) {

      await helpers.reply(msg, '❌ Search Error: ' + e.message);

    }

  }

};

