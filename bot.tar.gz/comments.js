// comments.js - Comment Management Module with Delete & Reply
// This module handles all comment-related operations

const fs = require('fs');
const path = require('path');

// File path for storing comments (JSON file)
const COMMENTS_FILE = path.join(__dirname, 'data', 'comments.json');

// Delete time limit (in milliseconds) - 5 minutes
const DELETE_TIME_LIMIT = 5 * 60 * 1000;

// Ensure data directory exists
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    console.log('📁 Created data directory for comments');
}

// Initialize comments file if it doesn't exist
if (!fs.existsSync(COMMENTS_FILE)) {
    fs.writeFileSync(COMMENTS_FILE, JSON.stringify([], null, 2));
    console.log('📝 Initialized comments.json file');
}

// 📖 Load comments from file
function loadComments() {
    try {
        const data = fs.readFileSync(COMMENTS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('❌ Error loading comments:', error);
        return [];
    }
}

// 💾 Save comments to file
function saveComments(comments) {
    try {
        fs.writeFileSync(COMMENTS_FILE, JSON.stringify(comments, null, 2));
        return true;
    } catch (error) {
        console.error('❌ Error saving comments:', error);
        return false;
    }
}

// 🔑 Generate session token for user delete validation
function generateSessionToken() {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 12)}`;
}

// 📝 Add new comment
function addComment(name, commentText, replyTo = null, replyToName = null) {
    try {
        // Validation
        if (!name || !commentText) {
            throw new Error('Name and comment text are required');
        }

        if (name.length > 50) {
            throw new Error('Name must be 50 characters or less');
        }

        if (commentText.length > 500) {
            throw new Error('Comment must be 500 characters or less');
        }

        // Load existing comments
        const comments = loadComments();

        // If replying, validate parent comment exists
        if (replyTo) {
            const parentExists = comments.some(c => c.id === replyTo);
            if (!parentExists) {
                throw new Error('Parent comment not found');
            }
        }

        // Generate session token for delete validation
        const sessionToken = generateSessionToken();

        // Create new comment object
        const newComment = {
            id: generateCommentId(),
            name: sanitizeInput(name),
            comment: sanitizeInput(commentText),
            timestamp: new Date().toISOString(),
            likes: 0,
            approved: true,
            replyTo: replyTo || null,
            replyToName: replyToName ? sanitizeInput(replyToName) : null,
            sessionToken: sessionToken // For user delete validation
        };

        // Add to beginning of array (newest first)
        comments.unshift(newComment);

        // Limit to last 100 comments
        const limitedComments = comments.slice(0, 100);

        // Save to file
        if (saveComments(limitedComments)) {
            console.log(`✅ New comment added by ${name}${replyTo ? ' (reply)' : ''}`);
            return newComment;
        } else {
            throw new Error('Failed to save comment');
        }
    } catch (error) {
        console.error('❌ Error adding comment:', error);
        throw error;
    }
}

// 📋 Get all approved comments
function getComments(limit = 50) {
    try {
        const comments = loadComments();

        // Filter approved comments only
        const approvedComments = comments.filter(c => c.approved);

        // Return comments but WITHOUT session tokens (security)
        const safeComments = approvedComments.map(c => {
            const { sessionToken, ...safeComment } = c;
            return safeComment;
        }).slice(0, limit);

        return safeComments;
    } catch (error) {
        console.error('❌ Error getting comments:', error);
        return [];
    }
}

// 👍 Add like to comment
function likeComment(commentId) {
    try {
        const comments = loadComments();

        // Find comment by ID
        const commentIndex = comments.findIndex(c => c.id === commentId);

        if (commentIndex === -1) {
            throw new Error('Comment not found');
        }

        // Increment likes
        comments[commentIndex].likes += 1;

        // Save updated comments
        if (saveComments(comments)) {
            console.log(`👍 Comment ${commentId} liked (total: ${comments[commentIndex].likes})`);

            // Return without session token
            const { sessionToken, ...safeComment } = comments[commentIndex];
            return safeComment;
        } else {
            throw new Error('Failed to update likes');
        }
    } catch (error) {
        console.error('❌ Error liking comment:', error);
        throw error;
    }
}

// 🗑️ Delete comment (user can delete within time limit)
function deleteComment(commentId, sessionToken) {
    try {
        const comments = loadComments();

        // Find comment by ID
        const commentIndex = comments.findIndex(c => c.id === commentId);

        if (commentIndex === -1) {
            throw new Error('Comment not found');
        }

        const comment = comments[commentIndex];

        // Check if session token matches (user authentication)
        if (comment.sessionToken !== sessionToken) {
            throw new Error('Unauthorized: Invalid session token');
        }

        // Check if within delete time limit (5 minutes)
        const commentAge = Date.now() - new Date(comment.timestamp).getTime();
        if (commentAge > DELETE_TIME_LIMIT) {
            throw new Error('Delete time limit exceeded (5 minutes)');
        }

        // Remove comment and all its replies
        const filteredComments = comments.filter(c => 
            c.id !== commentId && c.replyTo !== commentId
        );

        // Save updated comments
        if (saveComments(filteredComments)) {
            console.log(`🗑️ Comment ${commentId} deleted by user`);
            return true;
        } else {
            throw new Error('Failed to delete comment');
        }
    } catch (error) {
        console.error('❌ Error deleting comment:', error);
        throw error;
    }
}

// 📊 Get comment statistics
function getCommentStats() {
    try {
        const comments = loadComments();
        const approvedComments = comments.filter(c => c.approved);
        const totalLikes = comments.reduce((sum, c) => sum + c.likes, 0);
        const replies = comments.filter(c => c.replyTo !== null);

        return {
            totalComments: comments.length,
            approvedComments: approvedComments.length,
            pendingComments: comments.length - approvedComments.length,
            totalLikes: totalLikes,
            totalReplies: replies.length
        };
    } catch (error) {
        console.error('❌ Error getting comment stats:', error);
        return {
            totalComments: 0,
            approvedComments: 0,
            pendingComments: 0,
            totalLikes: 0,
            totalReplies: 0
        };
    }
}

// 🆔 Generate unique comment ID
function generateCommentId() {
    return `comment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// 🧹 Sanitize user input (basic XSS prevention)
function sanitizeInput(input) {
    return input
        .trim()
        .replace(/[<>]/g, '') // Remove < and > to prevent HTML injection
        .substring(0, 500); // Limit length
}

// 🔄 Approve comment (for manual moderation - optional)
function approveComment(commentId) {
    try {
        const comments = loadComments();
        const commentIndex = comments.findIndex(c => c.id === commentId);

        if (commentIndex === -1) {
            throw new Error('Comment not found');
        }

        comments[commentIndex].approved = true;

        if (saveComments(comments)) {
            console.log(`✅ Comment ${commentId} approved`);
            const { sessionToken, ...safeComment } = comments[commentIndex];
            return safeComment;
        } else {
            throw new Error('Failed to approve comment');
        }
    } catch (error) {
        console.error('❌ Error approving comment:', error);
        throw error;
    }
}

// Export all functions
module.exports = {
    addComment,
    getComments,
    likeComment,
    deleteComment,
    getCommentStats,
    approveComment
};