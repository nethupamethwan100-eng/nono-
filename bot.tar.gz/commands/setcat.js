const fs = require('fs')

const path = require('path')

const axios = require('axios')

const FormData = require('form-data')

const { downloadContentFromMessage } = require('@whiskeysockets/baileys')

const configPath = path.join(__dirname, '../config/default.json')

async function uploadToCatbox(buffer) {

    const bodyForm = new FormData();

    bodyForm.append("fileToUpload", buffer, "category.jpg");

    bodyForm.append("reqtype", "fileupload");

    const { data } = await axios.post("https://catbox.moe/user/api.php", bodyForm, {

        headers: bodyForm.getHeaders(),

    });

    return data;

}

module.exports = {

    name: 'setcat',

    category: 'admin',

    description: 'Update the category menu image',

    exec: async (sock, msg, args, { helpers, isOwner }) => {

        try {

            if (!isOwner) return helpers.reply(msg, '❌ Owner only!')

            const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage

            const imgMsg = msg.message.imageMessage || quoted?.imageMessage

            if (!imgMsg) return helpers.reply(msg, '🎬 Reply to an image with *.setcat*')

            await sock.sendMessage(msg.key.remoteJid, { react: { text: '⏳', key: msg.key } })

            const stream = await downloadContentFromMessage(imgMsg, 'image')

            let buffer = Buffer.from([])

            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])

            const imageUrl = await uploadToCatbox(buffer)

            const currentConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'))

            currentConfig.categoryImage = imageUrl // Updates Category Only

            fs.writeFileSync(configPath, JSON.stringify(currentConfig, null, 2))

            await helpers.reply(msg, `✅ *Category Image Updated!*\n${imageUrl}`)

        } catch (err) {

            await helpers.reply(msg, `❌ Error: ${err.message}`)

        }

    }

}

