const axios = require('axios');

const config = require('../config/default.json');

// Store video metadata for active sessions

const ytSessions = new Map();

module.exports = {

  name: 'youtube',

  alias: ['yt', 'ytdl', 'video'],

  category: 'download',

  description: 'Download YouTube videos with quality selection',

  handleReply: async (sock, msg, helpers) => {

    const sender = msg.key.remoteJid;

    const session = ytSessions.get(sender);

    if (!session) return false;

    const messageText = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

    const choice = messageText.trim();

    if (choice.toLowerCase() === 'exit') {

      ytSessions.delete(sender);

      await sock.sendMessage(sender, { react: { text: '✅', key: msg.key } });

      return true;

    }

    const qualities = ['144', '240', '360', '480', '720', '1080'];

    const index = parseInt(choice) - 1;

    if (index >= 0 && index < qualities.length) {

      const selectedQuality = qualities[index];

      

      try {

        // Step 1: React to show processing

        await sock.sendMessage(sender, { react: { text: '📥', key: msg.key } });

        // Step 2: Fetch Download Link

        const dlApi = `https://api.nekolabs.web.id/downloader/youtube/v1?url=${encodeURIComponent(session.url)}&format=${selectedQuality}`;

        const response = await axios.get(dlApi);

        const data = response.data;

        if (data.success && data.result.downloadUrl) {

          // Step 3: Send the Video File

          await sock.sendMessage(sender, { 

            video: { url: data.result.downloadUrl }, 

            caption: `✅ *${data.result.title}*\nQuality: ${selectedQuality}p`,

            fileName: `${data.result.title}.mp4`

          }, { quoted: msg });

          // Clear session after successful download

          ytSessions.delete(sender);

        } else {

          await helpers.reply(msg, '❌ Failed to generate download link.');

        }

      } catch (err) {

        await helpers.reply(msg, '❌ Download Error: ' + err.message);

      }

      return true;

    }

    return false;

  },

  exec: async (sock, msg, args, { helpers }) => {

    const sender = msg.key.remoteJid;

    const url = args[0];

    if (!url || !url.includes('youtu')) {

      return await helpers.reply(msg, '❌ Please provide a YouTube link.');

    }

    try {

      // React to show the bot is searching

      await sock.sendMessage(sender, { react: { text: '🔍', key: msg.key } });

      // Fetch Info API

      const infoApi = `https://api.nekolabs.web.id/downloader/youtube/v5?url=${encodeURIComponent(url)}`;

      const response = await axios.get(infoApi);

      const data = response.data;

      if (!data.success) {

        await sock.sendMessage(sender, { react: { text: '❌', key: msg.key } });

        return;

      }

      const res = data.result;

      const duration = new Date(res.lengthSeconds * 1000).toISOString().substr(11, 8);

      

      const menuText = `╭──[📽️ *YT DOWNLOAD* ]──╮
│ 📝 *Title:* ${res.title}
│ 👤 *Channel:* ${res.channelTitle}
│ ⏳ *Duration:* ${duration}
│ 👁️ *Views:* ${parseInt(res.viewCount).toLocaleString()}
╰──────────────────╯
*Select Quality:*
1️⃣ 144p
2️⃣ 240p
3️⃣ 360p
4️⃣ 480p
5️⃣ 720p
6️⃣ 1080p

▢ _plz ensure that *quality available*_
▢ _Reply with number to download_
▢ _Type *exit* to cancel_

${config.footer || ''}`;

      await helpers.sendImage(sender, res.thumbnail[res.thumbnail.length - 1].url, menuText);

      ytSessions.set(sender, {

        url: url,

        title: res.title,

        timestamp: Date.now()

      });

      // Clear reaction after menu is sent

      await sock.sendMessage(sender, { react: { text: '❇️', key: msg.key } });

      setTimeout(() => ytSessions.delete(sender), 300000);

    } catch (err) {

      await helpers.reply(msg, '❌ Info Error: ' + err.message);

    }

  }

};

