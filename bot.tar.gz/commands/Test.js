const config = require('../config/default.json')

// Store active test sessions for each user (expires after 5 minutes)

const userTestSessions = new Map()

module.exports = {

  name: 'test',

  alias: ['t'],

  category: 'fun',

  description: 'Test interactive poll system',

  

  // Handler for poll responses and number replies

  handleReply: async (sock, msg, helpers) => {

    try {

      // Check for poll update (vote response)

      const pollUpdate = msg.message?.pollUpdateMessage

      

      // Check for text message

      const messageText = 

        msg.message.conversation ||

        msg.message.extendedTextMessage?.text ||

        ''

      const sender = msg.key.remoteJid

      

      // Check if user has an active test session

      const sessionData = userTestSessions.get(sender)

      if (!sessionData) return false

      const choice = messageText.trim()

      // Handle different choices

      if (choice === '1') {

        await helpers.reply(msg, '✅ You selected: *Option 1 - Games*\n\n🎮 Gaming is awesome!\n\n_Send another number to try again!_')

        return true

      } 

      else if (choice === '2') {

        await helpers.reply(msg, '✅ You selected: *Option 2 - Movies*\n\n🎬 Cinema is amazing!\n\n_Send another number to try again!_')

        return true

      } 

      else if (choice === '3') {

        await helpers.reply(msg, '✅ You selected: *Option 3 - Music*\n\n🎵 Music is life!\n\n_Send another number to try again!_')

        return true

      }

      else if (choice === '4') {

        await helpers.reply(msg, '✅ You selected: *Option 4 - Books*\n\n📚 Reading is power!\n\n_Send another number to try again!_')

        return true

      }

      else if (choice.toLowerCase() === 'exit' || choice.toLowerCase() === 'stop') {

        await helpers.reply(msg, '👋 Session ended! Use `.test` to start again.')

        userTestSessions.delete(sender)

        return true

      }

      return false

    } catch (err) {

      return false

    }

  },

  exec: async (sock, msg, args, { helpers, PREFIX }) => {

    try {

      const sender = msg.key.remoteJid

      // Create interactive menu text

      const menuText = `╭──[ *✦ TEST MENU* ]─╮

│ 🎯 Select your favorite!

╰─────────────╯

    1️⃣ *Games*

    2️⃣ *Movies*

    3️⃣ *Music*

    4️⃣ *Books*

_Send number to select (1-4)_

_Type 'exit' to end session_

${config.footer}`

      // Send with poll (native Baileys support)

      try {

        await sock.sendMessage(sender, {

          poll: {

            name: '🎯 Select your favorite!',

            values: ['🎮 Games', '🎬 Movies', '🎵 Music', '📚 Books'],

            selectableCount: 1

          }

        })

        

        // Also send instruction text

        await helpers.sendText(sender, `_Vote above or send number (1-4)_\n\n${config.footer}`)

        

      } catch (pollErr) {

        // Fallback to image with text

        await helpers.sendImage(

          sender,

          'https://i.postimg.cc/5NLPczBD/Leonardo-Anime-XL-Animestyle-illustration-Narutoinspired-chara-2.jpg',

          menuText

        )

      }

      // Store user's session (expires after 5 minutes)

      userTestSessions.set(sender, {

        timestamp: Date.now()

      })

      // Auto-delete after 5 minutes

      setTimeout(() => {

        userTestSessions.delete(sender)

      }, 300000)

    } catch (err) {

      await helpers.reply(msg, '❌ Error: ' + err.message)

    }

  }

}