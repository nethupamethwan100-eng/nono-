const axios = require('axios');

const config = require('../config/default.json'); // Using config for branding

module.exports = {

  name: 'tiktok',

  alias: ['tt', 'ttdl'],

  description: 'Download TikTok videos automatically',

  category: 'download',

  exec: async (sock, msg, args, { helpers }) => {

    const url = args[0];

    

    // Validate input matching the style of your help command structure

    if (!url) {

      return helpers.reply(msg, `❌ *Usage:* .tt <tiktok_link>`);

    }

    await helpers.reply(msg, '⏳ *Processing your request...*');

    try {

      const apiUrl = `https://api.nekolabs.web.id/downloader/aio/v4?url=${encodeURIComponent(url)}`;

      const { data } = await axios.get(apiUrl);

      if (!data.success || !data.result) {

        return helpers.reply(msg, '❌ *Error:* Could not fetch video. Please check the link.');

      }

      const result = data.result;

      

      // Automatic selection logic:

      // 1. Try to find "HD No Watermark"

      // 2. If not found, try "HD Watermark"

      // 3. If neither found, take the first available media

      const video = result.medias.find(m => m.quality === 'HD No Watermark') || 

                    result.medias.find(m => m.quality === 'HD Watermark') || 

                    result.medias[0];

      // UI Styling matching your Help command layout

      const caption = `╭──[ 🎬 *TIKTOK DL*]─╮\n` +

                      `│ ▸ *Title:* ${result.title.substring(0, 50)}...\n` +

                      `│ ▸ *Quality:* ${video.quality}\n` +

                      `│ ▸ *Size:* ${video.formattedSize}\n` +                `╰───────────╯\n\n` +

                      `${config.footer}`; // Apply config footer

      // Send the video directly

      await sock.sendMessage(msg.key.remoteJid, {

        video: { url: video.url },

        caption: caption,

        mimetype: 'video/mp4'

      }, { quoted: msg });

    } catch (err) {

      console.error('TikTok DL Error:', err.message);

      helpers.reply(msg, '❌ *System Error:* Failed to process video.');

    }

  }

};

