const fs = require('fs')

const path = require('path')

const os = require('os')

const config = require('../config/default.json') // Loading from config/default.json

// Store help menu message IDs for tracking

const helpMenuMessages = new Map()

const getUptime = () => {

  const seconds = process.uptime();

  const d = Math.floor(seconds / (3600 * 24));

  const h = Math.floor((seconds % (3600 * 24)) / 3600);

  const m = Math.floor((seconds % 3600) / 60);

  return `${d}ᴅ ${h}ʜ ${m}ᴍ`;

}

module.exports = {

  name: 'help',

  alias: ['h', 'menu', 'commands'],
   description:'Bot manual',

  handleReply: async (sock, msg, helpers) => {

    try {

      const messageText = 

        msg.message.conversation ||

        msg.message.extendedTextMessage?.text ||

        ''

      const sender = msg.key.remoteJid

      const selectedNum = parseInt(messageText.trim())

      if (isNaN(selectedNum) || selectedNum < 1) return false

      let categoryData = null;

      const quotedMsg = msg.message?.extendedTextMessage?.contextInfo

      if (quotedMsg && quotedMsg.stanzaId) {

        categoryData = helpMenuMessages.get(quotedMsg.stanzaId)

      }

      if (!categoryData) {

        for (let [msgId, data] of helpMenuMessages.entries()) {

          if (data.recipient === sender) {

            categoryData = data;

            break;

          }

        }

      }

      if (!categoryData) return false

      const categories = categoryData.categories

      const categoryNum = selectedNum - 1

      if (categoryNum >= 0 && categoryNum < categories.length) {

        const selectedCategory = categories[categoryNum]

        const cmds = categoryData.commands[selectedCategory]

        const categoryEmojis = {

          'general': '⚙️', 'ai': '🤖', 'utility': '🛠️', 'search': '🔍',

          'converter': '🔄', 'media': '🎬', 'download': '📥', 'fun': '🎮',

          'admin': '👑', 'info': '📊'

        }

        const emoji = categoryEmojis[selectedCategory.toLowerCase()] || '✨'

        let categoryText = `╭─〔 ${emoji} *${selectedCategory.toUpperCase()}* 〕─╮\n`

        

        for (const cmd of cmds) {

          const aliases = cmd.alias ? ` (${cmd.alias.join(', ')})` : ''

          const desc = cmd.description || 'No description'

          categoryText += `│ ▸ *.${cmd.name}${aliases}*\n│   ↳ \`\`\`${desc}\`\`\`\n│\n`

        }

        categoryText += `╰─────────────╯\n\n${config.footer}`

        // UPDATED: Loading category image from JSON

        await helpers.sendImage(

          sender,

          config.categoryImage || config.menuImage, // Fallback to menuImage if categoryImage isn't set

          categoryText

        )

        return true 

      }

      return false

    } catch (err) {

      console.error('Help reply handler error:', err.message)

      return false

    }

  },

  exec: async (sock, msg, args, { helpers, PREFIX }) => {

    try {

      await sock.sendMessage(msg.key.remoteJid, { react: { text: '❇️', key: msg.key } })

      const commandPath = path.join(__dirname)

      const commandFiles = fs.readdirSync(commandPath).filter(f => f.endsWith('.js'))

      const commands = {}

      for (const file of commandFiles) {

        try {

          const cmd = require(path.join(commandPath, file))

          const category = cmd.category || 'general'

          if (!commands[category]) commands[category] = []

          commands[category].push(cmd)

        } catch (err) {

          console.error(`Error loading ${file}:`, err)

        }

      }

      const pushName = msg.pushName || 'User'

      const totalMem = (os.totalmem() / 1024 / 1024).toFixed(0)

      const usedMem = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)

      const cpuUsage = (process.cpuUsage().system / 1000000).toFixed(2)

      const uptime = getUptime()

      const numberEmojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟']

      let helpText = `╭──[ ʜᴇʟʟᴏ ${pushName.toUpperCase()} ]─╮
│ 🖇️ ᴘʀᴇꜰɪx : ${config.prefix}
│ 🧩 ᴄᴍᴅꜱ : ${commandFiles.length}
│ 🫟 ʀᴀᴍ : ${usedMem}/${totalMem} ᴍʙ
│ 📍ᴄᴘᴜ : ${cpuUsage}%
│ ⏳ ᴜᴘᴛɪᴍᴇ : ${uptime}
│ ❇️ ${config.botName.toUpperCase()} ᴀɪ
╰──────────────────╯\n\n`

      const categories = Object.keys(commands)

      categories.forEach((category, index) => {

        const emoji = numberEmojis[index] || '▸'

        helpText += `    ${emoji} *${category.charAt(0).toUpperCase() + category.slice(1)}*\n`

      })

      helpText += `\n ▢ _Reply with number to view category_\n\n${config.footer}`

      // UPDATED: Loading main menu image from JSON

      const sentMsg = await helpers.sendImage(

        msg.key.remoteJid,

        config.menuImage, 

        helpText

      )

      if (sentMsg?.key?.id) {

        helpMenuMessages.set(sentMsg.key.id, {

          categories,

          commands,

          recipient: msg.key.remoteJid,

          timestamp: Date.now()

        })

        setTimeout(() => {

          helpMenuMessages.delete(sentMsg.key.id)

        }, 300000)

      }

    } catch (err) {

      console.error('Help command error:', err.message)

      await helpers.reply(msg, '❌ Error loading help menu')

    }

  }

}

