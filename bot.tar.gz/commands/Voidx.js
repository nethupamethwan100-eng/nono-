const { downloadMediaMessage, getContentType } = require('@whiskeysockets/baileys');

const fs = require('fs').promises;

const path = require('path');

const dotenv = require('dotenv');

const axios = require('axios');

dotenv.config();

// Memory management functions

const MEMORY_DIR = path.join(__dirname, '../database/voidx_memory');

const MAX_MEMORY_MESSAGES = 10; // Keep last 10 messages per user

async function ensureMemoryDir() {

  try {

    await fs.mkdir(MEMORY_DIR, { recursive: true });

  } catch (error) {

    console.error('Error creating memory directory:', error);

  }

}

async function getMemoryPath(userId) {

  await ensureMemoryDir();

  const sanitizedId = userId.replace(/[^a-zA-Z0-9]/g, '_');

  return path.join(MEMORY_DIR, `${sanitizedId}.json`);

}

async function loadMemory(userId) {

  try {

    const memoryPath = await getMemoryPath(userId);

    const data = await fs.readFile(memoryPath, 'utf-8');

    return JSON.parse(data);

  } catch (error) {

    return []; // Return empty array if no memory exists

  }

}

async function saveMemory(userId, memory) {

  try {

    const memoryPath = await getMemoryPath(userId);

    // Keep only the last MAX_MEMORY_MESSAGES

    const trimmedMemory = memory.slice(-MAX_MEMORY_MESSAGES);

    await fs.writeFile(memoryPath, JSON.stringify(trimmedMemory, null, 2));

  } catch (error) {

    console.error('Error saving memory:', error);

  }

}

async function addToMemory(userId, role, content) {

  const memory = await loadMemory(userId);

  memory.push({

    role: role,

    content: content,

    timestamp: Date.now()

  });

  await saveMemory(userId, memory);

}

function formatMemoryForContext(memory) {

  if (memory.length === 0) return "";

  

  let context = "\n\n[Recent Conversation History]:\n";

  memory.forEach((msg, idx) => {

    const role = msg.role === 'user' ? 'User' : 'VOID X';

    context += `${role}: ${msg.content}\n`;

  });

  return context;

}

// Unlimited API for text-only requests

async function getTextOnlyResponse(prompt) {

  try {

    const encodedPrompt = encodeURIComponent(prompt);

    const apiUrl = `https://api.nekolabs.web.id/text.gen/gemini/2.0-flash?text=${encodedPrompt}`;

    

    const response = await axios.get(apiUrl, {

      timeout: 30000, // 30 second timeout

      headers: {

        'User-Agent': 'VOIDX-Bot/1.0'

      }

    });

    

    if (response.data && response.data.success && response.data.result) {

      return response.data.result;

    } else {

      throw new Error('Invalid API response format');

    }

  } catch (error) {

    console.error('Unlimited API Error:', error.message);

    throw error;

  }

}

// Official API for media analysis

async function getMediaResponse(parts, systemInstruction) {

  const { GoogleGenerativeAI } = require("@google/generative-ai");

  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

  

  const model = genAI.getGenerativeModel({ 

    model: "gemini-2.5-flash",

    systemInstruction: systemInstruction 

  });

  

  const result = await model.generateContent({ contents: [{ role: "user", parts }] });

  return result.response.text();

}

module.exports = {

  name: 'voidx',

  alias: ['void', 'vx', 'ai'],

  description: 'VOID X Premium AI for Nova Prime with Memory',

  category: 'ai',

  

  exec: async (sock, msg, args, { helpers }) => {

    // Get user ID for memory storage

    const userId = msg.key.remoteJid;

    

    // VOID X Identity & Context

    const systemInstruction = `You are *VOID X* ❇️, a premium AI for *Nova Prime WhatsApp Bot*, built by *Nethupa Methwan*.  

All responses go to *WhatsApp*, so keep them *chat-friendly*.

### Tone & Personality

- Friendly, confident, slightly edgy 😎  
- Polite, premium, sleek ✨  
- Adaptive: short for normal answers, add details only when needed  
- Sprinkle 1–3 emojis naturally 🎯💡🔥  

### Style
- Short paragraphs (1–3 lines max) 
- Readable and engaging for WhatsApp  

### Examples
**Quick:** “Got it ✅☠️. Done 😎.” 
**Medium:** “Understood 💡☠️. Step one… Step two… That should work 😎✨” 
**Expanded:** “Alright. Step by step: 1️⃣… 2️⃣… 3️⃣… 🔥”`;

    const mType = getContentType(msg.message);

    const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    

    const targetMsg = quotedMsg ? { message: quotedMsg } : msg;

    const targetType = getContentType(targetMsg.message);

    

    const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage'];

    const isMedia = mediaTypes.includes(targetType);

    

    let prompt = args.join(" ") || msg.message?.[mType]?.caption || "";

    

    // Special commands for memory management

    if (prompt.toLowerCase() === 'forget' || prompt.toLowerCase() === 'clear memory') {

      await saveMemory(userId, []);

      return await helpers.reply(msg, "🧠 Memory cleared! Starting fresh. ✨");

    }

    

    if (!prompt && !isMedia) {

      return await helpers.reply(msg, 

        "Hello! I'm *VOID X*, your premium AI for Nova Prime 😎. How can I assist you today? ✅\n\n" );

    }

    // Premium Typing Indicator & Reaction

    await helpers.react(msg, '❇️');

    await sock.presenceSubscribe(msg.key.remoteJid);

    await sock.sendPresenceUpdate('composing', msg.key.remoteJid);

    try {

      // Load conversation memory

      const memory = await loadMemory(userId);

      const memoryContext = formatMemoryForContext(memory);

      let userPrompt = prompt || "Analyze this for me, VOID X.";

      

      // Add memory context and system instruction to the prompt for text-only API

      const fullPrompt = systemInstruction + memoryContext + "\n\n[Current Message]:\n" + userPrompt;

      let aiResponse;

      // TEXT-ONLY REQUEST - Use unlimited API

      if (!isMedia) {

        console.log('🔄 Using unlimited API for text-only request...');

        aiResponse = await getTextOnlyResponse(fullPrompt);

      } 

      // MEDIA REQUEST - Use official API with key

      else {

        console.log('📸 Using official API for media analysis...');

        

        let parts = [{ text: memoryContext ? memoryContext + "\n\n[Current Message]:\n" + userPrompt : userPrompt }];

        

        const buffer = await downloadMediaMessage(targetMsg, 'buffer', {});

        const mimeType = targetMsg.message[targetType].mimetype;

        

        // Supported multimodal mimes for Gemini API

        const supportedMimes = [

          'image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif',

          'video/mp4', 'video/mpeg', 'video/mov', 'video/avi', 'video/x-flv', 'video/mpg', 'video/webm', 'video/wmv', 'video/3gpp',

          'audio/wav', 'audio/mp3', 'audio/aiff', 'audio/aac', 'audio/ogg', 'audio/flac',

          'application/pdf'

        ];

        if (supportedMimes.includes(mimeType)) {

          parts.push({

            inlineData: {

              data: buffer.toString("base64"),

              mimeType: mimeType

            }

          });

        } else {

          // If it's a code file (.js) or unsupported doc, convert to text

          const textContent = buffer.toString('utf-8');

          parts[0].text += `\n\n[File Content Attached]:\n${textContent}`;

        }

        

        aiResponse = await getMediaResponse(parts, systemInstruction);

      }

      // Save to memory (store simplified versions)

      const originalPrompt = prompt || "Analyze this for me, VOID X.";

      await addToMemory(userId, 'user', originalPrompt);

      await addToMemory(userId, 'assistant', aiResponse);

      // Stop typing indicator before replying

      await sock.sendPresenceUpdate('paused', msg.key.remoteJid);

      await helpers.react(msg, '✳️');

      

      await helpers.reply(msg, aiResponse);

    } catch (error) {

      console.error('VOID X Error:', error.message);

      await sock.sendPresenceUpdate('paused', msg.key.remoteJid);

      await helpers.react(msg, '❌');

      

      if (error.message.includes('429') || error.response?.status === 429) {

        await helpers.reply(msg, "🤍 *VOID X is under cooldown due to high load.*\n\nPlease try again in a moment! ");

      } else if (error.message.includes('400')) {

        await helpers.reply(msg, "🤔 VOID X here. It seems that file format isn't supported for direct analysis. Try sending it as a PDF or Text! 💎");

      } else if (error.message.includes('timeout') || error.message.includes('ECONNABORTED')) {

        await helpers.reply(msg, "⏱️ Request timed out. Please try again! 🔄");

      } else {

        await helpers.reply(msg, "⚠️ VOID X encountered an issue. Please try again later! ");

      }

    }

  }

};