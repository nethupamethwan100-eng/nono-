const { exec } = require('child_process')

module.exports = {

    name: 'restart',

    alias: ['reset', 'reboot'],

    category: 'admin',
    

    description: 'Restarts the bot process',

    exec: async (sock, msg, args, { helpers, isOwner }) => {

        try {

            // 1. Security Check

            if (!isOwner) return helpers.reply(msg, '❌ This is an Owner-only command!')

            await helpers.reply(msg, '🔄 *Restarting... Please wait a moment.*')

            

            // Give the bot a second to send the message before killing the process

            setTimeout(() => {

                process.exit() 

            }, 1000)

        } catch (err) {

            console.error('Restart Error:', err)

            await helpers.reply(msg, `❌ Error: ${err.message}`)

        }

    }

}

