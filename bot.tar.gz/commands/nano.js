const axios = require('axios');

const FormData = require('form-data');

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const config = require('../config/default.json');

/**

 * Uploads a buffer to Catbox.moe

 */

const uploadToCatbox = async (buffer) => {

    try {

        const bodyForm = new FormData();

        bodyForm.append('fileToUpload', buffer, { filename: 'nano.jpg' });

        bodyForm.append('reqtype', 'fileupload');

        

        const { data } = await axios.post('https://catbox.moe/user/api.php', bodyForm, {

            headers: bodyForm.getHeaders(),

        });

        return data; // Returns the direct link

    } catch (err) {

        throw new Error('Failed to upload to Catbox');

    }

};

module.exports = {

    name: 'nano',

    alias: ['edit', 'remini'],

    category: 'ai',

    description: 'Process images with Nano Banana AI',

    exec: async (sock, msg, args, { helpers }) => {

        const sender = msg.key.remoteJid;

        const prompt = args.join(' ');

        // 1. Check if the message is an image or replies to an image

        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        const isImage = msg.message?.imageMessage;

        const isQuotedImage = quoted?.imageMessage;

        if (!isImage && !isQuotedImage) {

            return await helpers.reply(msg, '❌ Please send or reply to an image with a prompt!\n\n*Example:* `.nano make her hair blue`');

        }

        if (!prompt) {

            return await helpers.reply(msg, '❌ Please provide a prompt (instructions) for the AI.');

        }

        try {

            // Send reaction to show processing

            await sock.sendMessage(sender, { react: { text: '⏳', key: msg.key } });

            // 2. Download the Image

            const targetMsg = isImage ? msg.message.imageMessage : quoted.imageMessage;

            const stream = await downloadContentFromMessage(targetMsg, 'image');

            let buffer = Buffer.from([]);

            for await (const chunk of stream) {

                buffer = Buffer.concat([buffer, chunk]);

            }

            // 3. Upload to Catbox

            const imageUrl = await uploadToCatbox(buffer);

            // 4. Call Nano Banana API

            const apiUrl = `https://apis.davidcyriltech.my.id/nanobanana?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`;

            const response = await axios.get(apiUrl);

            

            if (response.data.success) {

                const resultUrl = response.data.result.image;

                // 5. Send Result

                await helpers.sendImage(

                    sender,

                    resultUrl,

                    `✅ *Process Complete!*\n\n✨ *Prompt:* ${prompt}\n${config.footer}`

                );

                

                await sock.sendMessage(sender, { react: { text: '✅', key: msg.key } });

            } else {

                throw new Error('API returned success: false');

            }

        } catch (err) {

            console.error(err);

            await helpers.reply(msg, '❌ Error: ' + err.message);

            await sock.sendMessage(sender, { react: { text: '❌', key: msg.key } });

        }

    }

};

