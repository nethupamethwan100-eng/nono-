const fs = require('fs')
const path = require('path')

// Create logs directory if it doesn't exist
const logDir = path.join(__dirname, '../logs')
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true })
}

// Get current date for log file name
const getLogFileName = () => {
  const date = new Date()
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}.log`
}

// Format timestamp
const getTimestamp = () => {
  return new Date().toISOString()
}

// Write to log file
const writeLog = (level, message, data = null) => {
  const logFile = path.join(logDir, getLogFileName())
  const timestamp = getTimestamp()
  const logEntry = {
    timestamp,
    level,
    message,
    ...(data && { data })
  }

  const logLine = JSON.stringify(logEntry) + '\n'

  fs.appendFileSync(logFile, logLine, 'utf8')
}

// Logger methods
const logger = {
  info: (message, data) => {
    console.log(`[INFO] ${message}`, data || '')
    writeLog('INFO', message, data)
  },

  error: (message, error) => {
    console.error(`[ERROR] ${message}`, error || '')
    writeLog('ERROR', message, error ? {
      message: error.message,
      stack: error.stack
    } : null)
  },

  warn: (message, data) => {
    console.warn(`[WARN] ${message}`, data || '')
    writeLog('WARN', message, data)
  },

  debug: (message, data) => {
    if (process.env.DEBUG === 'true') {
      console.log(`[DEBUG] ${message}`, data || '')
      writeLog('DEBUG', message, data)
    }
  },

  command: (user, command, args) => {
    const message = `${user} executed: ${command} ${args.join(' ')}`
    console.log(`[CMD] ${message}`)
    writeLog('COMMAND', message)
  }
}

module.exports = logger